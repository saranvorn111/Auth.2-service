create function select_item_by_type(itype character varying)
    returns TABLE(iid integer, icode character varying, idescription character varying, iunit character varying, iqty integer, iimage character varying, istatus boolean, icapacity character varying, iprice real)
    language plpgsql
as
$$BEGIN
	-- Routine body goes here...
	
		IF(itype = 'a') THEN	
				RETURN QUERY(SELECT id, items.code, description, unit, qty, image, status, capacity, price_out_a FROM items WHERE status = true);
		END IF;
		
		if (itype = 'b') THEN 
				RETURN QUERY(SELECT id, items.code, description, unit, qty, image, status, capacity, price_out_b FROM items WHERE status = true);
		END IF;
		
		if (itype = 'c') THEN 
				RETURN QUERY(SELECT id, items.code, description, unit, qty, image, status, capacity, price_out_c FROM items WHERE status = true);
		END IF;
		
END$$;

alter function select_item_by_type(varchar) owner to postgres;

