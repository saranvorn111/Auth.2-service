create view sold_out_items_summary_report(id, code, description, capacity, qty, stockout, actualcount) as
SELECT items.id,
       items.code,
       items.description,
       items.capacity,
       stock_count.qty,
       invoice_detail.qty AS stockout,
       items.qty          AS actualcount
FROM items
         JOIN stock_count ON items.id = stock_count.item_id
         JOIN invoice_detail ON items.id = invoice_detail.item_id
         JOIN invoices ON invoices.id = invoice_detail.invoice_id;

alter table sold_out_items_summary_report
    owner to postgres;

