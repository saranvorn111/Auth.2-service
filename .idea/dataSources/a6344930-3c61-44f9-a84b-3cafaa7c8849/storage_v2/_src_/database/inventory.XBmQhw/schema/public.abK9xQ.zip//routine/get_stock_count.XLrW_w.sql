create function get_stock_count()
    returns TABLE(id integer, item_id integer, stock_count_date timestamp without time zone, qty integer)
    language plpgsql
as
$$
begin
	 RETURN query (SELECT * FROM stock_count WHERE date_trunc('month', stock_count.stock_count_date) = date_trunc('month', NOW()));
end;
$$;

alter function get_stock_count() owner to postgres;

