create function update_stock_count(types integer, iid integer, stock_date timestamp without time zone, update_qty integer)
    returns TABLE(dd integer, did integer, d_date timestamp without time zone, dqty integer)
    language plpgsql
as
$$BEGIN
	-- Routine body goes here...

	if(types = 1) THEN
		
			UPDATE stock_count SET
			stock_count_date = stock_date,
			qty = qty + update_qty
			WHERE item_id = iid AND 
			date_trunc('month', stock_count.stock_count_date) = date_trunc('month', stock_date::TIMESTAMP);
	
	ELSE
			
			UPDATE stock_count SET
			stock_count_date = stock_date,
			qty = qty - update_qty
			WHERE item_id = iid AND 
			date_trunc('month', stock_count.stock_count_date) = date_trunc('month', stock_date::TIMESTAMP);
			
	END IF;
	
	RETURN;
END$$;

alter function update_stock_count(integer, integer, timestamp, integer) owner to postgres;

