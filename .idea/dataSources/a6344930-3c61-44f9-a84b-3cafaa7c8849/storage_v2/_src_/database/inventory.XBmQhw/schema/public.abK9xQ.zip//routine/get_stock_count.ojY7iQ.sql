create function get_stock_count(monthly timestamp without time zone)
    returns TABLE(id integer, item_id integer, stock_count_date timestamp without time zone, qty integer)
    language plpgsql
as
$$
begin
   
	 RETURN QUERY(SELECT * FROM stock_count WHERE date_trunc('month', stock_count.stock_count_date) = date_trunc('month', monthly));
end;
$$;

alter function get_stock_count(timestamp) owner to postgres;

