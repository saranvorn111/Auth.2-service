create function summary_monthly_report("currentMonth" timestamp without time zone, "startDate" timestamp without time zone, "endDate" timestamp without time zone, type character varying)
    returns TABLE(iid integer, icode character varying, idesc character varying, icapacity character varying, istock_in_count integer, istock_out bigint, iactoul_count bigint)
    language plpgsql
as
$$BEGIN
	-- Routine body goes here...
		IF($4 = 'S') THEN	
				
				RETURN QUERY (SELECT id, code, description, capacity, stock_count,SUM(stockout) as stock_out, stock_count - SUM(stockout) as actualcount
									FROM summary_monthly_report
									WHERE 
									date_trunc('month', summary_monthly_report.purchased_date) = date_trunc('month', $1)
									AND date_trunc('day', summary_monthly_report.purchased_date)
									BETWEEN
									date_trunc('day', $2)
									AND 
									date_trunc('day', $3)
									GROUP BY id, code, description, capacity, actualcount, stock_count);
				END IF;
	
		IF($4 = 'NS') THEN	
				RETURN QUERY (SELECT id, code, description, capacity, stock_count, CAST ('0' AS BIGINT) as stock_out,  CAST (actualcount AS BIGINT) 
									FROM summary_monthly_report
									WHERE
									summary_monthly_report.purchased_date IS NULL);
				
			END IF;
		
		
END$$;

alter function summary_monthly_report(timestamp, timestamp, timestamp, varchar) owner to postgres;

