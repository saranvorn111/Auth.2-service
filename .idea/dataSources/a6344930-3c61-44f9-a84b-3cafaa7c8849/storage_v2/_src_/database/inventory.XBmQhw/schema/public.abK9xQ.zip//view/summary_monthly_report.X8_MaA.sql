create view summary_monthly_report
            (id, code, description, capacity, stock_count, stockout, actualcount, purchased_date, stock_count_date) as
SELECT items.id,
       items.code,
       items.description,
       items.capacity,
       stock_count.qty AS stock_count,
       CASE
           WHEN invoice_detail.qty IS NULL THEN 0
           ELSE invoice_detail.qty
           END         AS stockout,
       items.qty       AS actualcount,
       invoices.purchased_date,
       stock_count.stock_count_date
FROM items
         LEFT JOIN stock_count ON items.id = stock_count.item_id AND
                                  date_trunc('month'::text, stock_count.stock_count_date) =
                                  date_trunc('month'::text, now())
         FULL JOIN invoice_detail ON items.id = invoice_detail.item_id
         FULL JOIN invoices ON invoices.id = invoice_detail.invoice_id;

alter table summary_monthly_report
    owner to postgres;

