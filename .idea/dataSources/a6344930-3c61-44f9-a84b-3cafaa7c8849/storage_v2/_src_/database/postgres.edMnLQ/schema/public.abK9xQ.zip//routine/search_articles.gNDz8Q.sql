create function search_articles(keyword character varying)
    returns TABLE(id integer, title character varying)
    language plpgsql
as
$$
begin
    return query
        select a.id, a.title
        from articles as a
        where a.title ilike '%' || keyword || '%';
end;
$$;

alter function search_articles(varchar) owner to postgres;

