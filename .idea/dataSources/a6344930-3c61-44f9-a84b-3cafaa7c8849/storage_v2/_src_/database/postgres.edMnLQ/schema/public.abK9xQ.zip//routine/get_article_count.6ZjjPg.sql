create function get_article_count(keyword character varying) returns integer
    language plpgsql
as
$$
declare
    article_count integer;
begin
    select count(*)
    into article_count
    from articles
    where title ilike '%' || keyword || '%';

    return article_count;
end;
$$;

alter function get_article_count(varchar) owner to postgres;

