create function get_e_voucher_by_user_id(userid integer)
    returns TABLE(id integer, user_id integer, voucher_stamp_id integer, achieved_date timestamp without time zone, expired_date timestamp without time zone, is_active boolean, stamp_hint text, priority_number integer, instruction text, voucher_id integer, detail text)
    language plpgsql
as
$$BEGIN

			RETURN QUERY (SELECT uv.id, uv.user_id, uv.voucher_stamp_id, uv.achieved_date, uv.expired_date, uv.is_active, vouchers_stamps.stamp_hint , vouchers_stamps.priority_number, vouchers_stamps.instruction, vouchers_stamps.voucher_id, vouchers_stamps.detail
										FROM users_vouchers AS uv
										INNER JOIN vouchers_stamps
										on uv.voucher_stamp_id = vouchers_stamps.id
										WHERE uv.user_id = userId order by vouchers_stamps.id asc);
										
	RETURN;
END$$;

alter function get_e_voucher_by_user_id(integer) owner to postgres;

