create function get_latest_current_stamp_by_user_id(userid integer)
    returns TABLE(id integer, user_id integer, voucher_stamp_id integer, achieved_date timestamp without time zone, expired_date timestamp without time zone, is_active boolean, stamp_hint text, instruction text, priority_number integer, detail text)
    language plpgsql
as
$$BEGIN

			RETURN QUERY (SELECT uv.* ,
										vouchers_stamps.stamp_hint,
										vouchers_stamps.instruction,
										vouchers_stamps.priority_number,
										vouchers_stamps.detail
										FROM users_vouchers AS uv
										INNER JOIN vouchers_stamps
										on uv.voucher_stamp_id = vouchers_stamps.id
										WHERE uv.user_id = userId  AND uv.is_active = TRUE ORDER BY uv.achieved_date DESC, uv.voucher_stamp_id DESC LIMIT 1);
	RETURN;
END$$;

alter function get_latest_current_stamp_by_user_id(integer) owner to postgres;

